Arquivo zip gerado em: 01/07/2020 21:33:47 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [2] Tempo de uso de um servidor