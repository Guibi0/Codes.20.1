Arquivo zip gerado em: 01/07/2020 20:51:49 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [2] Divisibilidade de números