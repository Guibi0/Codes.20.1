Arquivo zip gerado em: 01/07/2020 19:42:31 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [1] Expoente