Arquivo zip gerado em: 07/07/2020 02:13:21 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [3 - Funções/String] Particionamento de string