Arquivo zip gerado em: 01/07/2020 21:29:44 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [2] Multiplos