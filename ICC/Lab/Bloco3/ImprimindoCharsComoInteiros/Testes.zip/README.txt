Arquivo zip gerado em: 01/07/2020 23:22:06 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [3 - Alocação Dinâmica Vetor] Imprimindo chars como inteiros