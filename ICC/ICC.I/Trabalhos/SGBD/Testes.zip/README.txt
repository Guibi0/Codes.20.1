Arquivo zip gerado em: 02/07/2020 20:43:10 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Banco de dados